//
//  RegisterViewController.swift
//  Teresa
//
//  Created by Mohana Akash Nukala on 6/20/17.
//

import UIKit
import Firebase
import ProgressHUD

class DonorRegisterViewController: UIViewController {
    
    @IBOutlet weak var signupEmailInputView: AMInputView!
    @IBOutlet weak var signupNameInputView: AMInputView!
    @IBOutlet weak var signupAddressInputView: AMInputView!
    @IBOutlet weak var signupDescriptionInputView: AMInputView!
    @IBOutlet weak var signupPhoneNumberInputView: AMInputView!
    @IBOutlet weak var signupPasswordConfirmInputView: AMInputView!
    
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var logoImage: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var bio: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var phone: UILabel!
    @IBOutlet weak var popup: UIView!

    @IBOutlet weak var signupButton: UIButton!
    var selectedImage: UIImage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        popup.isHidden = true
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        signupButton.layer.cornerRadius = 20
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleSelectProfileImageView))
        profileImage.addGestureRecognizer(tapGesture)
        profileImage.isUserInteractionEnabled = true
        NotificationCenter.default.addObserver(self, selector: #selector(RegisterViewController.keyboardWillShow(sender:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(RegisterViewController.keyboardWillHide(sender:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
    }
    @objc func keyboardWillShow(sender: NSNotification) {
        self.view.frame.origin.y = -100 // Move view 150 points upward
    }
    
    @objc func keyboardWillHide(sender: NSNotification) {
        self.view.frame.origin.y = 0 // Move view to original position
    }
    @objc func handleSelectProfileImageView() {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        present(pickerController, animated: true, completion: nil)
    }
    @IBAction func signUpBtn_TouchUpInside(_ sender: AnyObject) {
        
        if(signupNameInputView.textFieldView.text! == "")
        {
            ProgressHUD.showError("Name can't be empty")
            return
        }
        view.endEditing(true)
        ProgressHUD.show("Waiting...", interaction: false)
        if(selectedImage == nil)
        {
            selectedImage = profileImage.image
        }
        if let profileImg = self.selectedImage, let imageData = UIImageJPEGRepresentation(profileImg,0.2) {//change this sign up
            AuthService.donorSignUp(name:signupNameInputView.textFieldView.text!, description:signupDescriptionInputView.textFieldView.text!, number: signupPhoneNumberInputView.textFieldView.text!, address: signupAddressInputView.textFieldView.text!, email: signupEmailInputView.textFieldView.text!, password: signupPasswordConfirmInputView.textFieldView.text!, imageData: imageData, onSuccess: {
                ProgressHUD.showSuccess("Success")
                
                self.name.text = self.signupNameInputView.textFieldView.text!
                self.bio.text = self.signupDescriptionInputView.textFieldView.text!
                self.phone.text = self.signupPhoneNumberInputView.textFieldView.text!
                self.email.text = self.signupEmailInputView.textFieldView.text!
                self.logoImage.image = self.selectedImage
                let deadlineTime = DispatchTime.now() + .seconds(1)
                DispatchQueue.main.asyncAfter(deadline: deadlineTime) {
                    self.navigationController?.isNavigationBarHidden = true
                    self.popup.isHidden = false
//                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//                    let sendVC = storyboard.instantiateViewController(withIdentifier: "Donor")
//                    self.present(sendVC, animated: true, completion: nil)
                }
                
            }, onError: { (errorString) in
                print(errorString)
                ProgressHUD.showError(errorString!)
            })
        } else {
            ProgressHUD.showSuccess("Profile Photo error")
        }
    }
    
}
extension DonorRegisterViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        print("did Finish Picking Media")
        if let image = info["UIImagePickerControllerOriginalImage"] as? UIImage{
            selectedImage = image
            profileImage.image = image
        }
        dismiss(animated: true, completion: nil)
    }
}


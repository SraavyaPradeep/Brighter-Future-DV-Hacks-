//
//  QuestionBank.swift
//  Quizzler
//
//  Created by Atharva Kulkarni on 1/4/19.
//  Copyright © 2019 Atharva Kulkarni. All rights reserved.
//

import Foundation

class QuestionBank {
    
    //array of Question objects
    var list : [Question] = []    //var list = [Question]()   -> another way

    
    // constructor
    init() {
        
        // Add the Question to the list of questions
        list.append(Question(qText: "How do you find your maximum heartrate?", correctAnswer: 2, aText1: "250 - Your Age", aText2: "220 - Your Age", aText3: "195 - Half Your Age"))
        
        list.append(Question(qText: "After intense weight training, how many hours does it take to rebuild muscle?", correctAnswer: 3, aText1: "2", aText2: "6", aText3: "24"))
        
        list.append(Question(qText: "How much calcium per day does an adolescent need?", correctAnswer: 3, aText1: "900 mg", aText2: "1,200 mg", aText3: "1,300 mg"))
        
        list.append(Question(qText: "Routine physical examinations should be done how often during the teen years?", correctAnswer: 1, aText1: "Annually", aText2: "Every 2 years", aText3: "Every 3 years"))
        
        list.append(Question(qText: "At least how many steps should you be taking every day?", correctAnswer: 3, aText1: "8,000", aText2: "12,000", aText3: "10,000"))
        
        list.append(Question(qText: "How do you calculate your average protein needs?", correctAnswer: 2, aText1: "0.8 grams/kg", aText2: "1 gram/kg", aText3: "1.4 g.kg"))
        
        list.append(Question(qText: "Exercise has been proven to", correctAnswer: 3, aText1: "Reduce the risk of diabetes", aText2: "Increase bone mass", aText3: "Both of the above"))
        
        list.append(Question(qText: "Exercise is a must for", correctAnswer: 2, aText1: "Body Tone", aText2: "Health", aText3: "Physical skills"))
        
        list.append(Question(qText: "At least how many hours of sleep should teens get?", correctAnswer: 1, aText1: "9", aText2: "7", aText3: "8"))
        
        list.append(Question(qText: "What added nutrients do teenagers require during rapid growth?", correctAnswer: 3, aText1: "Magnesium and calcium", aText2: "Various minerals and vitamins", aText3: "Both of the above"))
        
        list.append(Question(qText: "Which of the following is a good source of protein? ", correctAnswer: 3, aText1: "Beans", aText2: "Lean beef", aText3: "Both of the above"))
        
        list.append(Question(qText: "An example of a complete protein", correctAnswer: 1, aText1: "Quinoa", aText2: "Rice", aText3: "Potato"))
        
        list.append(Question(qText: "The key to achieving success in any improving physical fitness is", correctAnswer: 2, aText1: "Access to gym equipment", aText2: "Goal setting", aText3: "A good trainer"))
        
        
        
        
       
        
    
    }
    
}

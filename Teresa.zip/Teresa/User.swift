//
//  User.swift
//Alive
//
//  Created by Mohana Nukala on 12/30/17.
//  Copyright ©2018High Development Mobile Applications Inc. All rights reserved.
//

import Foundation
import FirebaseDatabase
class UserModel {
    var email: String?
    var profileImageUrl: String?
    var coverImageUrl: String?
    var username: String?
    var name: String?
    var steps: Int?
    var id: String?
    var bio: String?
    var REF_USERS = Database.database().reference().child("users")

    func observeUser(withId uid: String, completion: @escaping (UserModel?) -> Void) {
        REF_USERS.child(uid).observeSingleEvent(of: .value, with: {
            snapshot in
            if let dict = snapshot.value as? [String: Any] {
                let user = UserModel.transformUser(dict: dict, key: snapshot.key)
                completion(user)
            } else {
                completion(nil)
            }
        })
    }
}

extension UserModel {
    static func transformUser(dict: [String: Any], key: String) -> UserModel {
        let user = UserModel()
        user.email = dict["email"] as? String
        user.profileImageUrl = dict["profileImageUrl"] as? String
        user.coverImageUrl = dict["coverImageUrl"] as? String
        user.username = dict["username"] as? String
        user.name = dict["name"] as? String
        user.steps = dict["steps"] as? Int
        user.bio = dict["bio"] as? String
        user.id = key
        return user
    }
}

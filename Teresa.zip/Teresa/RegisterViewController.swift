//
//  RegisterViewController.swift
//  Teresa
//
//  Created by Mohana Akash Nukala on 6/20/17.
//

import UIKit
import Firebase
import ProgressHUD

class RegisterViewController: UIViewController {

    @IBOutlet weak var signupEmailInputView: AMInputView!
    @IBOutlet weak var signupNameInputView: AMInputView!
    @IBOutlet weak var signupPasswordConfirmInputView: AMInputView!
    
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var signupButton: UIButton!
    var selectedImage: UIImage?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        signupButton.layer.cornerRadius = 20
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleSelectProfileImageView))
        profileImage.addGestureRecognizer(tapGesture)
        profileImage.isUserInteractionEnabled = true
        NotificationCenter.default.addObserver(self, selector: #selector(RegisterViewController.keyboardWillShow(sender:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(RegisterViewController.keyboardWillHide(sender:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)

    }
    @objc func keyboardWillShow(sender: NSNotification) {
        self.view.frame.origin.y = -100 // Move view 150 points upward
    }
    
    @objc func keyboardWillHide(sender: NSNotification) {
        self.view.frame.origin.y = 0 // Move view to original position
    }
    @objc func handleSelectProfileImageView() {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        present(pickerController, animated: true, completion: nil)
    }
    @IBAction func signUpBtn_TouchUpInside(_ sender: AnyObject) {
            if(signupNameInputView.textFieldView.text! == "")
            {
                ProgressHUD.showError("Name can't be empty")
                return
            }
            view.endEditing(true)
            ProgressHUD.show("Waiting...", interaction: false)
            if(selectedImage == nil)
            {
                selectedImage = profileImage.image
            }
            if let profileImg = self.selectedImage, let imageData = UIImageJPEGRepresentation(profileImg,0.2) {
                AuthService.signUp(name: signupNameInputView.textFieldView.text!, email: signupEmailInputView.textFieldView.text!, password: signupPasswordConfirmInputView.textFieldView.text!, imageData: imageData, onSuccess: {
                    ProgressHUD.showSuccess("Success")
                    
                    
                    let deadlineTime = DispatchTime.now() + .seconds(1)
                    DispatchQueue.main.asyncAfter(deadline: deadlineTime) {
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        let sendVC = storyboard.instantiateViewController(withIdentifier: "Live")
                        self.present(sendVC, animated: true, completion: nil)
                    }
                    
                }, onError: { (errorString) in
                    print(errorString)
                    ProgressHUD.showError(errorString!)
                })
            } else {
                ProgressHUD.showSuccess("Profile Photo error")
        }
        }
    
}
extension RegisterViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        print("did Finish Picking Media")
        if let image = info["UIImagePickerControllerOriginalImage"] as? UIImage{
            selectedImage = image
            profileImage.image = image
        }
        dismiss(animated: true, completion: nil)
    }
}


//
//  AuthService.swift
//
//  Created by Mohana Nukala on 12/17/17.
//

import Foundation
import FirebaseAuth
import FirebaseStorage
import FirebaseDatabase
import MapKit

class AuthService {
    
    static func signIn(email: String, password: String, onSuccess: @escaping () -> Void, onError:  @escaping (_ errorMessage: String?) -> Void) {
        Auth.auth().signIn(withEmail: email, password: password, completion: { (user, error) in
            if error != nil {
                onError(error!.localizedDescription)
                return
            }
            
            onSuccess()
        })
        
    }
    
    static func signUp(name:String, email: String, password: String, imageData: Data, onSuccess: @escaping () -> Void, onError:  @escaping (_ errorMessage: String?) -> Void) {
        Auth.auth().createUser(withEmail: email, password: password, completion: { (user ,error) in
            if error != nil {
                onError(error!.localizedDescription)
                return
            }
            let uid = user?.user.uid
            let storageRef = Storage.storage().reference(forURL: Config.STORAGE_ROOF_REF).child("profile_image").child(uid!)
            storageRef.putData(imageData, metadata: nil, completion: { (metadata, error) in
                if error != nil {
                    return
                }
                guard let metadata = metadata else {
                    // Uh-oh, an error occurred!
                    return
                }
                // Metadata contains file metadata such as size, content-type.
                let size = metadata.size
                // You can also access to download URL after upload.
                storageRef.downloadURL { (url, error) in
                    guard let profileImageUrl = url else {
                        // Uh-oh, an error occurred!
                        return
                }
                    self.setUserInfomation(name: name, profileImageUrl: profileImageUrl.absoluteString, email: email, uid: uid!, onSuccess: onSuccess)

                }
            })
        })
        
    }
    static func donorSignUp(name:String, description:String, number: String, address: String, email: String, password: String, imageData: Data, onSuccess: @escaping () -> Void, onError:  @escaping (_ errorMessage: String?) -> Void) {
        Auth.auth().createUser(withEmail: email, password: password, completion: { (user ,error) in
            if error != nil {
                onError(error!.localizedDescription)
                return
            }
            let uid = user?.user.uid
            let storageRef = Storage.storage().reference(forURL: Config.STORAGE_ROOF_REF).child("profile_image").child(uid!)
            storageRef.putData(imageData, metadata: nil, completion: { (metadata, error) in
                if error != nil {
                    return
                }
                guard let metadata = metadata else {
                    // Uh-oh, an error occurred!
                    return
                }
                // Metadata contains file metadata such as size, content-type.
                let size = metadata.size
                // You can also access to download URL after upload.
                storageRef.downloadURL { (url, error) in
                    guard let profileImageUrl = url else {
                        // Uh-oh, an error occurred!
                        return
                    }
                    self.setRestaurantInfomation(name:name, description:description, number: number, address: address, email: email, uid: uid!, profileImageUrl: profileImageUrl.absoluteString, onSuccess: onSuccess)
                    
                }
            })
        })
        
    }
    static func setUserInfomation(name:String, profileImageUrl: String, email: String, uid: String, onSuccess: @escaping () -> Void) {
        
        let ref = Database.database().reference()
        let usersReference = ref.child("users")
        let newUserReference = usersReference.child(uid)
        newUserReference.setValue(["name": name, "email": email, "profileImageUrl": profileImageUrl,"steps":0])
        onSuccess()
    }
    static func setRestaurantInfomation(name:String, description:String, number: String, address: String, email: String, uid: String, profileImageUrl: String, onSuccess: @escaping () -> Void) {
        
        let ref = Database.database().reference()
        let usersReference = ref.child("restaurants")
        let newUserReference = usersReference.child(uid)
        let fullAddress = address
        let geoCoder = CLGeocoder()
        print(fullAddress)
        geoCoder.geocodeAddressString(fullAddress) { (placemarks, error) in
            if
                let placemarks = placemarks,
                let location = placemarks.first?.location
            {
                    newUserReference.setValue(["hotelName": name, "email": email, "hotelImageUrl": profileImageUrl,"description":description, "hotelPhone": number, "hotelLatitude": String(location.coordinate.latitude),"hotelLongitude":String(location.coordinate.longitude)])
                    onSuccess()
                    // handle no location found
                    return
            }
        }
        

    }
    static func updateUserInfor(name:String, email: String, imageData: Data, onSuccess: @escaping () -> Void, onError:  @escaping (_ errorMessage: String?) -> Void) {
        Api.User.CURRENT_USER?.updateEmail(to: email, completion: { (error) in
            if error != nil {
                onError(error!.localizedDescription)
            }else {
                let uid = Api.User.CURRENT_USER?.uid
                let storageRef = Storage.storage().reference(forURL: Config.STORAGE_ROOF_REF).child("profile_image").child(uid!)
                print("updatingdatabse0")

                storageRef.putData(imageData, metadata: nil, completion: { (metadata, error) in
                    if error != nil {
                        return
                    }

                    guard let metadata = metadata else {
                        // Uh-oh, an error occurred!
                        return
                    }
                    // Metadata contains file metadata such as size, content-type.
                    let size = metadata.size
                    // You can also access to download URL after upload.
                    print("updatingdatabse1")

                    storageRef.downloadURL { (url, error) in
                        guard let profileImageUrl = url else {
                            // Uh-oh, an error occurred!
                            return
                    }
                    print("updatingdatabse2")
                    self.updateDatabase(name: name, profileImageUrl: profileImageUrl.absoluteString, email: email, onSuccess: onSuccess, onError: onError)
//
                        
                    }
                })
            }
        })
        
    }
    
    static func updateDatabase(name: String, profileImageUrl: String, email: String, onSuccess: @escaping () -> Void, onError:  @escaping (_ errorMessage: String?) -> Void) {
        let dict = ["name": name,"email": email, "profileImageUrl": profileImageUrl]
        Api.User.REF_CURRENT_USER?.updateChildValues(dict, withCompletionBlock: { (error, ref) in
            if error != nil {
                onError(error!.localizedDescription)
            } else {
                onSuccess()
            }
            
        })
    }
    
    static func logout(onSuccess: @escaping () -> Void, onError:  @escaping (_ errorMessage: String?) -> Void) {
        do {
            try Auth.auth().signOut()
            onSuccess()
            
        } catch let logoutError {
            onError(logoutError.localizedDescription)
        }
    }
}

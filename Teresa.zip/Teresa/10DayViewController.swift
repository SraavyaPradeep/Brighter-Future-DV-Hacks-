//
//  10DayViewController.swift
//  Teresa
//
//  Created by Mohana Akash Nukala on 1/13/19.
//  Copyright © 2019 Mohana Nukala. All rights reserved.
//

import UIKit

class DayViewController: UIViewController {
    @IBOutlet weak var popup: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        popup.clipsToBounds = true
        popup.layer.cornerRadius = 20
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

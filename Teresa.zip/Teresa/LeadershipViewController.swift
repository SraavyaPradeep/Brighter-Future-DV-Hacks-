//
//  LeaderboardViewController.swift
//  TimerTest
//
//  Created by Sraavya Pradeep on 1/13/19.
//  Copyright © 2019 Sraavya Pradeep. All rights reserved.
//

import UIKit

class LeaderboardViewController: UIViewController {
    
    
    
    @IBOutlet weak var underline: UILabel!
    
    // Person 1
    @IBOutlet weak var pfp1: UIImageView!
    @IBOutlet weak var name1: UILabel!
    @IBOutlet weak var steps1: UILabel!
    
    // Person 2
    @IBOutlet weak var pfp2: UIImageView!
    @IBOutlet weak var name2: UILabel!
    @IBOutlet weak var steps2: UILabel!
    
    // Person 3
    @IBOutlet weak var pfp3: UIImageView!
    @IBOutlet weak var name3: UILabel!
    @IBOutlet weak var steps3: UILabel!
    
    // Person 4
    @IBOutlet weak var pfp4: UIImageView!
    @IBOutlet weak var name4: UILabel!
    @IBOutlet weak var steps4: UILabel!
    
    // Person 5
    @IBOutlet weak var pfp5: UIImageView!
    @IBOutlet weak var name5: UILabel!
    @IBOutlet weak var steps5: UILabel!
    
    // Person 6
    @IBOutlet weak var pfp6: UIImageView!
    @IBOutlet weak var name6: UILabel!
    @IBOutlet weak var steps6: UILabel!
    
    // Person 7
    @IBOutlet weak var pfp7: UIImageView!
    @IBOutlet weak var name7: UILabel!
    @IBOutlet weak var steps7: UILabel!
    
    // Person 8
    @IBOutlet weak var pfp8: UIImageView!
    @IBOutlet weak var name8: UILabel!
    @IBOutlet weak var steps8: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.pfp1.layer.cornerRadius = self.pfp1.frame.width / 2
        self.pfp2.layer.cornerRadius = self.pfp2.frame.width / 2
        self.pfp3.layer.cornerRadius = self.pfp3.frame.width / 2
        self.pfp4.layer.cornerRadius = self.pfp4.frame.width / 2
        self.pfp5.layer.cornerRadius = self.pfp5.frame.width / 2
        self.pfp6.layer.cornerRadius = self.pfp6.frame.width / 2
        self.pfp7.layer.cornerRadius = self.pfp7.frame.width / 2
        self.pfp8.layer.cornerRadius = self.pfp8.frame.width / 2
        
        self.name1.layer.cornerRadius = 20
        self.name2.layer.cornerRadius = 20
        self.name3.layer.cornerRadius = 20
        self.name4.layer.cornerRadius = 20
        self.name5.layer.cornerRadius = 20
        self.name6.layer.cornerRadius = 20
        self.name7.layer.cornerRadius = 20
        self.name8.layer.cornerRadius = 20
        
        self.steps1.layer.cornerRadius = 20
        self.steps2.layer.cornerRadius = 20
        self.steps3.layer.cornerRadius = 20
        self.steps4.layer.cornerRadius = 20
        self.steps5.layer.cornerRadius = 20
        self.steps6.layer.cornerRadius = 20
        self.steps7.layer.cornerRadius = 20
        self.steps8.layer.cornerRadius = 20
        
        
        //    self.underline.layer.cornerRadius = 20
        
        
    }
    
    
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

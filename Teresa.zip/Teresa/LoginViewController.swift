//
//  LoginViewController.swift
//  Teresa
//
//  Created by Mohana Akash Nukala on 6/20/17.
//

import UIKit
import Firebase
import ProgressHUD
import AVFoundation
import FirebaseAuth
fileprivate let registerSegue = "registerSegueIdentifier"

let placeholderTextColor = UIColor(red: 0.36, green: 0.30, blue: 0.25, alpha: 1)


class LoginViewController: UIViewController {
   
    @IBOutlet var email: AMInputView!
    @IBOutlet var password: AMInputView!
    @IBOutlet var loginButton: UIButton!
    @IBOutlet var singupButton: UIButton!
    var avPlayer: AVPlayer!
    var avPlayerLayer: AVPlayerLayer!
    var paused: Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        print("start1")
        loginButton.layer.cornerRadius = 25
 
        print("start3")

        let theURL = Bundle.main.url(forResource:"video", withExtension: "mov")
        avPlayer = AVPlayer(url: theURL!)
        avPlayerLayer = AVPlayerLayer(player: avPlayer)
        avPlayerLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        avPlayer.volume = 0
        avPlayer.actionAtItemEnd = .none
        avPlayerLayer.frame = view.layer.bounds
        view.backgroundColor = .clear
        view.layer.insertSublayer(avPlayerLayer, at: 0)
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(playerItemDidReachEnd(notification:)),
                                               name: NSNotification.Name.AVPlayerItemDidPlayToEndTime,
                                               object: avPlayer.currentItem)
        
        let launchedBefore = UserDefaults.standard.bool(forKey: "launchedBefore")
        if launchedBefore  {
         } else {
             UserDefaults.standard.set(true, forKey: "launchedBefore")
        }
 
        NotificationCenter.default.addObserver(self, selector: #selector(LoginViewController.keyboardWillShow(sender:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(LoginViewController.keyboardWillHide(sender:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
    }
    @objc func keyboardWillShow(sender: NSNotification) {
        self.view.frame.origin.y = -100 // Move view 150 points upward
    }
    
    @objc func keyboardWillHide(sender: NSNotification) {
        self.view.frame.origin.y = 0 // Move view to original position
    }
    @objc func playerItemDidReachEnd(notification: Notification) {
        let p: AVPlayerItem = notification.object as! AVPlayerItem
        p.seek(to: kCMTimeZero)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        avPlayer.play()
        paused = false
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
 
    
    @IBAction func loginAsVolunteer() {
        
        Auth.auth().signIn(withEmail: email.textFieldView.text!, password: password.textFieldView.text!) { (user, error) in
            if let error = error {
                let errorMessage: String
                if error.localizedDescription == "There is no user record corresponding to this identifier. The user may have been deleted." {
                    errorMessage = "Sorry. We didn’t recognize that email address. Please try again."
                }
                else {
                    errorMessage = "Sorry. We didn’t recognize that password. Please re-enter or use 'Forgot Password'."
                }
                
                let alertController = UIAlertController(title: "Error", message: errorMessage, preferredStyle: UIAlertControllerStyle.alert)
                
                let okAction = UIAlertAction(title: "OK", style: .default) {
                    (result : UIAlertAction) -> Void in
                }
                alertController.addAction(okAction)
                self.present(alertController, animated: true, completion: nil)
                return
                
            }
            else{
                let deadlineTime = DispatchTime.now() + .seconds(1)
                DispatchQueue.main.asyncAfter(deadline: deadlineTime) {
//                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//                    let sendBeerVC = storyboard.instantiateViewController(withIdentifier: "Live")
//                    self.present(sendBeerVC, animated: true, completion: nil)
                    if let tabbar = (self.storyboard?.instantiateViewController(withIdentifier: "Live") as? UITabBarController) {
                        self.present(tabbar, animated: true, completion: nil)
                    }
                }
            }
        }
    }

    func textFieldEditingEnd(_ textField: UITextField) {
        loginButton.isEnabled = !email.textFieldView.text!.isEmpty && !password.textFieldView.text!.isEmpty
    }
}

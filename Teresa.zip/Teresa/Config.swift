//
//  Config.swift
//
//  Created by Mohana Nukala on 12/17/17.
//  Copyright ©2018High Development Mobile Applications Inc. All rights reserved.
//

import Foundation
struct Config {
    static var STORAGE_ROOF_REF = "gs://brighter-future-5ec68.appspot.com"
    static let numberOfObjectsToLoad:UInt = 750

}

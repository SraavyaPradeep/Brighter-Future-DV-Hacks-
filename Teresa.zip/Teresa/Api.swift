//
//  Api.swift
//
//  Created by Mohana Nukala on 1/8/17.
//  Copyright © 2017 High Development Mobile Applications Inc. All rights reserved.
//

import Foundation
struct Api {
    static var User = UserApi()
}

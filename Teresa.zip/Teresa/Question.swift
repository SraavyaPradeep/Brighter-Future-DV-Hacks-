 //
 //  Question.swift
 //  Quizzler
 //
 //  Created by Atharva Kulkarni on 1/3/19.
 //  Copyright © 2019 Atharva Kulkarni. All rights reserved.
 //
 
 // Foundation is basically a light weight version of UIKit to import
 import Foundation
 
 class Question {
    
    // these are constant 'properties' of the question class, bascically instance variables
    let questionText : String
    let answer : Int
    let answerText1 : String
    let answerText2 : String
    let answerText3 : String
    
    // basically a constructor
    init(qText: String, correctAnswer: Int, aText1 : String, aText2 : String, aText3 : String) {
        questionText = qText
        answer = correctAnswer
        answerText1 = aText1
        answerText2 = aText2
        answerText3 = aText3
        
    }
    
    
    
 }
 
 
 
